x = parseInt(prompt("Digite un numero: "))

if (x%2===0){
    alert("el numero " + x + " es par")
}
else {
    alert("el numero " + x + " es impar")
}