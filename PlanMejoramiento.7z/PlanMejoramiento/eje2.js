Peso = parseFloat(prompt("Digite su peso en kilogramos: "));
Estatura = parseFloat(prompt("Digite su estatura en metros cuadrados: "));

imc = Peso / Estatura;

alert("su imc es: " +imc)