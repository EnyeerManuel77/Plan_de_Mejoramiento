Grados = parseFloat(prompt("Grados centigrados: "))
x = 1.8
y = 32

z = Grados * x + y

alert("Los grados centigrados convertido en forenkei es: "+z);